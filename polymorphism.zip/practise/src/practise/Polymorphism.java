package practise;

class eat{      //using a function call multiple objects
    public void fruit() {
    	System.out.println("All vegies are not fruits"); } }   
    class apple extends eat{
    	 public void fruit() {
    		 System.out.println("Apple is a fruit"); }}
    class orange extends eat{
    	 public void fruit() {
    		 System.out.println("Orange is a fruit"); }}
public class Polymorphism {
	public static void main(String[] args) {
	eat e=new eat();
	eat apple=new apple();
	eat orange=new orange();
    e.fruit();
    apple.fruit();
    orange.fruit();
	}

}
